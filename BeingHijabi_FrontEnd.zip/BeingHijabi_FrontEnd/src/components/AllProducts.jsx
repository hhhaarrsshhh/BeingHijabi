import PageTitle from "./sub-components/PageTitle";

const AllProducts = () => {
  return (
    <div>
      <PageTitle pageTitle={"All Products"} />
    </div>
  );
};

export default AllProducts;
