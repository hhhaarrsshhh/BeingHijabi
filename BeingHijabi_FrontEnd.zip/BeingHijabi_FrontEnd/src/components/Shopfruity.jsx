import PageTitle from "./sub-components/PageTitle";

const Shopfruity = () => {
  return (
    <div>
      <PageTitle pageTitle={"Fragrence Fruity"} />
    </div>
  );
}

export default Shopfruity