import PageTitle from "./sub-components/PageTitle";

const Shopwoody = () => {
  return (
    <div>
      <PageTitle pageTitle={"Woody Fragrances"} />
    </div>
  );
};

export default Shopwoody;
