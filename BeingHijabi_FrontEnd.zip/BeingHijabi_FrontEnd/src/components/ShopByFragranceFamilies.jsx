
const ShopByFragranceFamilies = () => {
  return (
    <div>
      <h1>Shop by Fragrance Families</h1>
      <p>Explore our diverse fragrance families.</p>
    </div>
  );
};

export default ShopByFragranceFamilies;
