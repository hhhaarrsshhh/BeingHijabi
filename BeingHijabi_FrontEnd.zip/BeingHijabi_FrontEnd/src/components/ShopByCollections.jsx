const ShopByCollections = () => {
  return <div>ShopByCollections</div>;
};

export default ShopByCollections;
