import PageTitle from "./sub-components/PageTitle";

const Shopperfum = () => {
  return (
    <div>
      <PageTitle pageTitle={"Perfume "} />
    </div>
  );
};

export default Shopperfum;
