import PageTitle from "./sub-components/PageTitle";

const Shopfloral = () => {
  return (
    <div>
      <PageTitle pageTitle={"Fragrence Floral"} />
    </div>
  );
}

export default Shopfloral