
const ShopByFamilies = () => {
  return (
    <div>ShopByFamilies</div>
  )
}

export default ShopByFamilies