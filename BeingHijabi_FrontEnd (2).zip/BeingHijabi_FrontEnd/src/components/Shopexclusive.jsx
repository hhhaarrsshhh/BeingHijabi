import PageTitle from "./sub-components/PageTitle";

const Shopexclusive = () => {
  return (
    <div>
      <PageTitle pageTitle={"Exclusive"} />
    </div>
  );
};

export default Shopexclusive;
