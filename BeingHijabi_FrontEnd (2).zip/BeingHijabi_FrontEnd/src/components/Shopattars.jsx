import PageTitle from "./sub-components/PageTitle";

const Shopattars = () => {
  return (
    <div>
      <PageTitle pageTitle={"Attars"} />
    </div>
  );
};

export default Shopattars;
