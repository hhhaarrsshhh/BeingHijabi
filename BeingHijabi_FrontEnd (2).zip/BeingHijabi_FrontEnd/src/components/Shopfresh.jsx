import PageTitle from "./sub-components/PageTitle";

const Shopfresh = () => {
  return (
    <div>
      <PageTitle pageTitle={"Fragrence Fresh"} />
    </div>
  );
}

export default Shopfresh