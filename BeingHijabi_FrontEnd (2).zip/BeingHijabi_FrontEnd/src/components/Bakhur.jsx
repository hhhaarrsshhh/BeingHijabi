import PageTitle from "./sub-components/PageTitle";

const Bakhur = () => {
  return (
    <div>
      <PageTitle pageTitle={"Bakhur"} />
    </div>
  );
};

export default Bakhur;
