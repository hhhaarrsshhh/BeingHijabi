import PageTitle from "./sub-components/PageTitle";

const Shoporiental = () => {
  return (
    <div>
      <PageTitle pageTitle={"Fragrence Oriental"} />
    </div>
  );
};

export default Shoporiental;
