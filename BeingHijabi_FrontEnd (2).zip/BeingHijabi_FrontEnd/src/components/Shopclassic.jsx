import PageTitle from "./sub-components/PageTitle"


const Shopclassic = () => {
  return (
    <div>
    <PageTitle pageTitle={"Classic Fragrences"}/>
    </div>
  )
}

export default Shopclassic