const ShopByCategories = () => {
  return <div>ShopByCategories</div>;
};

export default ShopByCategories;
